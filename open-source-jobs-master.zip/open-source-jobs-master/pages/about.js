function About() {
  return <p>Welcome to About!</p>;
}

export default About;
