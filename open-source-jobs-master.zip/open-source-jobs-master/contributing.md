# Contribution Guidelines

- To add a new org: click https://github.com/t9tio/open-source-jobs/issues/new?assignees=&labels=&template=add-a-new-organization.md&title=%5BOrg+Post%5D%3A
- To add a new job: click https://github.com/t9tio/open-source-jobs/issues/new?assignees=&labels=&template=post-a-new-job.md&title=%5BJob+Post%5D%3A
