---
name: Suggest a new repo for help-wanted page
about: Suggest a new repo for help-wanted page
title: "[Suggest a new repo for help-wanted page]: "
labels: ''
assignees: ''

---

Requirements: 
- [ ] the repo has more than 1000 stars
- [ ] the repo has issues tagged with `help-wanted`
